package com.ericsson.dsmcc.tool;

import java.util.*;
import java.nio.*;
import java.net.*;
import com.ericsson.dsmcc.tool.entity.*;
import java.io.*;
import org.slf4j.*;

public class SetupBuilder
{
    private static final Logger log;
    private String catId;
    private String tsid;
    private String serviceArea;
    private String deliveryId;
    private Set<Map.Entry<String, String>> optionalAppData;
    private String nsapServerIp;
    private String stbAddr;
    private int sessionNumber;
    private int transactionId;
    private String processingIp;
    private byte[] stbAddrAsBytes;
    
    public SetupBuilder(final String catId, final String tsid, final String serviceArea, final String deliveryId, final String nsapServerIp, final String sessionStbAddr, final int sessionNumber, final String processingIp, final int transactionId) {
        this.catId = catId;
        this.tsid = tsid;
        this.serviceArea = serviceArea;
        this.deliveryId = deliveryId;
        this.nsapServerIp = nsapServerIp;
        this.stbAddr = sessionStbAddr;
        this.sessionNumber = sessionNumber;
        this.processingIp = processingIp;
        this.transactionId = transactionId;
    }
    
    public SetupBuilder(final String nsapServerIp, final String sessionStbAddr, final int sessionNumber, final String processingIp, final int transactionId) {
        this.nsapServerIp = nsapServerIp;
        this.stbAddr = sessionStbAddr;
        this.sessionNumber = sessionNumber;
        this.processingIp = processingIp;
        this.transactionId = transactionId;
    }
    
    public ReleaseBuilder getReleaseBuilder() {
        return new ReleaseBuilder(this.stbAddr, this.sessionNumber);
    }
    
    private String buildAppData() {
        final StringBuilder sb = new StringBuilder();
        sb.append("catId=").append(this.catId).append(";");
        if (!Utils.isNil(this.tsid)) {
            sb.append("tsid=").append(this.tsid).append(";");
        }
        if (!Utils.isNil(this.serviceArea)) {
            sb.append("serviceArea=").append(this.serviceArea).append(";");
        }
        sb.append("deliveryId=").append(this.deliveryId);
        return sb.toString();
    }
    
    private String buildAppData2() {
        final StringBuilder sb = new StringBuilder();
        this.optionalAppData.stream().forEach(me -> sb.append(me.getKey()).append("=").append((String)me.getValue()).append(";"));
        return sb.toString();
    }
    
    public DsmccSetupMessage build() throws Exception {
        this.stbAddrAsBytes = Utils.parseMacAddress(this.stbAddr);
        final DsmccSetupMessage dsm = new DsmccSetupMessage();
        int msgLen = 52;
        dsm.setStbAddr(this.stbAddrAsBytes);
        dsm.setSessionNumber(ByteBuffer.allocate(4).putInt(this.sessionNumber).array());
        dsm.setMessageReserved(ByteBuffer.allocate(2).putShort((short)0).array());
        dsm.setClientNsapAfi((byte)45);
        dsm.setClientPadding1(ByteBuffer.allocate(12).array());
        dsm.setClientId(this.stbAddrAsBytes);
        dsm.setClientPadding2(ByteBuffer.allocate(1).array());
        dsm.setServerNsapAfi((byte)45);
        dsm.setServerPadding1(ByteBuffer.allocate(8).array());
        dsm.setServerIp(InetAddress.getByName(this.nsapServerIp).getAddress());
        dsm.setServerPadding2(ByteBuffer.allocate(7).array());
        int privDataLength = 11;
        dsm.setProtocolId((byte)1);
        dsm.setVersion((byte)0);
        dsm.setDescriptorCount((byte)2);
        dsm.setNodeGroupIdTag(DsmccSpec.ResourceTag.NodeGroup.code());
        dsm.setNodeGroupIdLength((byte)6);
        dsm.setNodeGroupIdData(ByteBuffer.allocate(6).array());
        dsm.setAppReqDataTag(DsmccSpec.ResourceTag.AppReqData.code());
        final String appData = this.buildAppData2();
        final byte[] appDataBytes = appData.getBytes();
        final int appDataLen = appDataBytes.length;
        dsm.setAppReqDataLength((byte)appDataLen);
        dsm.setAppReqData(appDataBytes);
        privDataLength += appDataLen + 1 + 1;
        dsm.setUudataLength(ByteBuffer.allocate(2).putShort((short)0).array());
        dsm.setPrivateDataLength(ByteBuffer.allocate(2).putShort((short)privDataLength).array());
        msgLen += privDataLength + 4;
        dsm.setProtocolDescriminator((byte)17);
        dsm.setDsmccType((byte)2);
        dsm.setMessageId(ByteBuffer.allocate(2).putShort(DsmccSpec.MessageID.ClientSetupRequest.code()).array());
        dsm.setTransactionid(ByteBuffer.allocate(4).putInt(this.transactionId).array());
        dsm.setHeaderReserved((byte)(-1));
        dsm.setAdaptationLength((byte)0);
        dsm.setMessageLength(ByteBuffer.allocate(2).putShort((short)msgLen).array());
        return dsm;
    }
    
    public void emitRuby(final DsmccSetupMessage setupMsg, final DsmccReleaseMessage releaseMsg) throws Exception {
        final String setupRubyBin = Utils.asRubyBinaryLiteral(setupMsg.toBytes());
        SetupBuilder.log.info("REQUEST: \n{}\n\n", (Object)setupMsg.pretty());
        final String setupRubyScript = Utils.readResource("/dsmcc_setup.rb").replaceAll("@RUBY-BIN@", setupRubyBin).replaceAll("@PROC-ADDR@", this.processingIp);
        final String releaseRubyScript = Utils.readResource("/dsmcc_release.rb").replaceAll("@RUBY-BIN@", Utils.asRubyBinaryLiteral(releaseMsg.toBytes())).replaceAll("@PROC-ADDR@", this.processingIp);
        final String stamp = String.valueOf(System.currentTimeMillis());
        final File setupRubyFile = new File("/tmp/dsmcc_setup_" + stamp + ".rb");
        final File releaseRubyFile = new File("/tmp/dsmcc_release_" + stamp + ".rb");
        final FileOutputStream setupFos = new FileOutputStream(setupRubyFile);
        setupFos.write(setupRubyScript.getBytes());
        setupFos.close();
        final FileOutputStream relFos = new FileOutputStream(releaseRubyFile);
        relFos.write(releaseRubyScript.getBytes());
        relFos.close();
        releaseRubyFile.setExecutable(true);
        setupRubyFile.setExecutable(true);
        SetupBuilder.log.info("Generated   SETUP Ruby Script: {}", (Object)setupRubyFile.getAbsolutePath());
        SetupBuilder.log.info("Generated RELEASE Ruby Script: {}", (Object)releaseRubyFile.getAbsolutePath());
    }
    
    public SetupBuilder setCatId(final String catId) {
        this.catId = catId;
        return this;
    }
    
    public SetupBuilder setTsid(final String tsid) {
        this.tsid = tsid;
        return this;
    }
    
    public SetupBuilder setServiceArea(final String serviceArea) {
        this.serviceArea = serviceArea;
        return this;
    }
    
    public SetupBuilder setDeliveryId(final String deliveryId) {
        this.deliveryId = deliveryId;
        return this;
    }
    
    public SetupBuilder setOptionalAppData(final Set<Map.Entry<String, String>> optionalAppData) {
        this.optionalAppData = optionalAppData;
        this.optionalAppData.stream().forEach(me -> SetupBuilder.log.info("Extra AppReqData: {} --> {}", me.getKey(), (Object)me.getValue()));
        return this;
    }
    
    static {
        log = LoggerFactory.getLogger((Class)SetupBuilder.class);
    }
}
