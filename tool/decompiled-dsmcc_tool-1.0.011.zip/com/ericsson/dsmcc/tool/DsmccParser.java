package com.ericsson.dsmcc.tool;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.net.*;
import com.ericsson.dsmcc.tool.entity.*;
import org.slf4j.*;

public class DsmccParser
{
    private static final Logger log;
    private byte[] sourceData;
    private File sourceFile;
    
    public DsmccParser(final File f) throws Exception {
        this.sourceFile = f;
        final FileInputStream instream = new FileInputStream(this.sourceFile);
        final long filesize = this.sourceFile.length();
        DsmccParser.log.info("file-size: " + filesize);
        instream.read(this.sourceData = new byte[(int)filesize]);
        instream.close();
    }
    
    public DsmccSetupMessage parseSetup() throws Exception {
        final byte[] d = this.sourceData;
        final DsmccSetupMessage msg = new DsmccSetupMessage();
        msg.setProtocolDescriminator(d[0]);
        msg.setDsmccType(d[1]);
        msg.setMessageId(d[2], d[3]);
        msg.setTransactionid(d[4], d[5], d[6], d[7]);
        DsmccParser.log.info("transaction-id: {}", (Object)ByteBuffer.wrap(msg.getTransactionid()).getInt());
        msg.setHeaderReserved(d[8]);
        msg.setAdaptationLength(d[9]);
        msg.setMessageLength(d[10], d[11]);
        DsmccParser.log.info("messageLengthInt: " + msg.getMessageLengthAsInt());
        final byte[] stbAddr = Arrays.copyOfRange(d, 12, 18);
        msg.setStbAddr(stbAddr);
        final byte[] sessionNumber = Arrays.copyOfRange(d, 18, 22);
        msg.setSessionNumber(sessionNumber);
        DsmccParser.log.info("stbaddr: {}", (Object)Utils.asHex("", msg.getStbAddr()));
        DsmccParser.log.info("session-number: {}", (Object)new String(msg.getSessionNumber()));
        DsmccParser.log.info("session-number: {}", (Object)ByteBuffer.wrap(msg.getSessionNumber()).getInt());
        msg.setMessageReserved(d[22], d[23]);
        msg.setClientNsapAfi(d[24]);
        msg.setClientPadding1(Arrays.copyOfRange(d, 25, 37));
        msg.setClientId(Arrays.copyOfRange(d, 37, 43));
        msg.setClientPadding2(Arrays.copyOfRange(d, 43, 44));
        msg.setServerNsapAfi(d[44]);
        msg.setServerPadding1(Arrays.copyOfRange(d, 45, 53));
        msg.setServerIp(Arrays.copyOfRange(d, 53, 57));
        msg.setServerPadding2(Arrays.copyOfRange(d, 57, 64));
        final InetAddress addr = InetAddress.getByAddress(msg.getServerIp());
        DsmccParser.log.info("serverIP-addr: {}", (Object)addr);
        final byte[] uudataLength = Arrays.copyOfRange(d, 64, 66);
        msg.setUudataLength(uudataLength);
        final int uudataLengthInt = msg.getUudataLengthAsInt();
        DsmccParser.log.info("uudataLengthInt: " + uudataLengthInt);
        final byte[] privdataLength = Arrays.copyOfRange(d, 66, 68);
        msg.setPrivateDataLength(privdataLength);
        final int privdataLengthInt = msg.getPrivateDataLengthAsInt();
        DsmccParser.log.info("privdataLenInt: " + privdataLengthInt);
        msg.setProtocolId(d[68]);
        msg.setVersion(d[69]);
        msg.setDescriptorCount(d[70]);
        final int descriptorCountInt = msg.getDescriptorCountAsInt();
        DsmccParser.log.info("descriptor-count: {}", (Object)descriptorCountInt);
        msg.setNodeGroupIdTag(d[71]);
        msg.setNodeGroupIdLength(d[72]);
        final int nodeGrpIdLengthInt = msg.getNodeGroupIdLengthAsInt();
        DsmccParser.log.info("nodeGroupLengthInt: " + nodeGrpIdLengthInt);
        int readPos = 73;
        int readTo = readPos + nodeGrpIdLengthInt;
        msg.setNodeGroupIdData(Arrays.copyOfRange(d, readPos, readTo));
        DsmccParser.log.info("node-group-data: {}", (Object)Utils.asHex("-", msg.getNodeGroupIdData()));
        readPos = readTo;
        msg.setAppReqDataTag(d[readPos]);
        ++readPos;
        msg.setAppReqDataLength(d[readPos]);
        final int appReqDataLengthInt = msg.getAppReqDataLengthAsInt();
        readTo = ++readPos + appReqDataLengthInt;
        final byte[] appReqData = Arrays.copyOfRange(d, readPos, readTo);
        msg.setAppReqData(appReqData);
        readPos += appReqDataLengthInt;
        DsmccParser.log.info("app-data-string: " + new String(msg.getAppReqData()));
        return msg;
    }
    
    public DsmccReleaseMessage parseRelease() throws Exception {
        final byte[] d = this.sourceData;
        final DsmccReleaseMessage msg = new DsmccReleaseMessage();
        msg.setProtocolDescriminator(d[0]);
        msg.setDsmccType(d[1]);
        msg.setMessageId(d[2], d[3]);
        msg.setTransactionid(d[4], d[5], d[6], d[7]);
        DsmccParser.log.info("transaction-id: {}", (Object)ByteBuffer.wrap(msg.getTransactionid()).getInt());
        msg.setHeaderReserved(d[8]);
        msg.setAdaptationLength(d[9]);
        msg.setMessageLength(d[10], d[11]);
        DsmccParser.log.info("messageLengthInt: " + msg.getMessageLengthAsInt());
        final byte[] stbAddr = Arrays.copyOfRange(d, 12, 18);
        msg.setStbAddr(stbAddr);
        final byte[] sessionNumber = Arrays.copyOfRange(d, 18, 22);
        msg.setSessionNumber(sessionNumber);
        DsmccParser.log.info("stbaddr: {}", (Object)Utils.asHex("", msg.getStbAddr()));
        DsmccParser.log.info("session-number: {}", (Object)new String(msg.getSessionNumber()));
        DsmccParser.log.info("session-number: {}", (Object)ByteBuffer.wrap(msg.getSessionNumber()).getInt());
        msg.setMessageReserved(d[22], d[23]);
        final byte[] uudataLength = Arrays.copyOfRange(d, 24, 26);
        msg.setUudataLength(uudataLength);
        final int uudataLengthInt = msg.getUudataLengthAsInt();
        DsmccParser.log.info("uudataLengthInt: " + uudataLengthInt);
        final byte[] privdataLength = Arrays.copyOfRange(d, 26, 28);
        msg.setPrivateDataLength(privdataLength);
        final int privdataLengthInt = msg.getPrivateDataLengthAsInt();
        DsmccParser.log.info("privdataLenInt: " + privdataLengthInt);
        final int readTo = 28 + privdataLengthInt;
        final byte[] privateData = Arrays.copyOfRange(d, 28, readTo);
        msg.setPrivateData(privateData);
        return msg;
    }
    
    public byte[] getSourceData() {
        return this.sourceData;
    }
    
    static {
        log = LoggerFactory.getLogger((Class)DsmccParser.class);
    }
}
