package com.ericsson.dsmcc.tool;

import java.util.*;
import com.ericsson.dsmcc.tool.entity.*;
import java.util.prefs.*;
import org.slf4j.*;

public class Main
{
    private static final Logger log;
    private List<String> argList;
    private Map<String, String> argMap;
    
    public Main(final String[] args) throws Exception {
        this.argList = Arrays.asList(args);
        this.argMap = new HashMap<String, String>();
        for (final String s : this.argList) {
            final String[] parts = s.trim().split("=");
            this.argMap.put(parts[0], parts[1]);
        }
        this.argMap.entrySet().stream().forEach(me -> Main.log.info("{} --> {}", me.getKey(), (Object)me.getValue()));
        final String s2;
        final String mode = s2 = this.argMap.get("mode");
        switch (s2) {
            case "setup": {
                this.doSetup();
                break;
            }
            default: {
                Main.log.error("unknown mode: {}", (Object)mode);
                break;
            }
        }
    }
    
    public void doSetup() throws Exception {
        final int sessNum = getSessionNumber();
        int transId;
        if (this.argMap.containsKey("transactionid")) {
            transId = Integer.parseInt(this.argMap.remove("transactionid"));
        }
        else {
            transId = 1237722379;
        }
        final String mode = this.argMap.remove("mode");
        final SetupBuilder dsb = new SetupBuilder(this.argMap.remove("serverip"), this.argMap.remove("stbaddr"), sessNum, this.argMap.remove("processingip"), transId);
        dsb.setOptionalAppData(this.argMap.entrySet());
        final DsmccSetupMessage setupMsg = dsb.build();
        final ReleaseBuilder rb = dsb.getReleaseBuilder();
        final DsmccReleaseMessage relMsg = rb.build();
        dsb.emitRuby(setupMsg, relMsg);
    }
    
    public static void main(final String[] args) throws Exception {
        new Main(args);
    }
    
    private static int getSessionNumber() {
        final Preferences prefs = Preferences.userRoot().node(Main.class.getName());
        final int sessionNum;
        int stored = sessionNum = prefs.getInt("session.number", 1080000000);
        ++stored;
        prefs.putInt("session.number", stored);
        Main.log.info("The Session Number will be: {}", (Object)sessionNum);
        return sessionNum;
    }
    
    static {
        log = LoggerFactory.getLogger((Class)Main.class);
    }
}
