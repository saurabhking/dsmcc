package com.ericsson.dsmcc.tool;

import org.slf4j.*;

public class Constants
{
    private static final Logger log;
    public static final int SETUP_DFLT_TRANSID = 1237722379;
    public static final int RELEASE_DFLT_TRANSID = -940572630;
    
    static {
        log = LoggerFactory.getLogger((Class)Constants.class);
    }
}
