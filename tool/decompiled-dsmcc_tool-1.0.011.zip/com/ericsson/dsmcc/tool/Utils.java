package com.ericsson.dsmcc.tool;

import java.util.*;
import java.io.*;

public class Utils
{
    public static String asHex(final byte... data) {
        final StringBuilder sb = new StringBuilder();
        for (final byte b : data) {
            sb.append(Integer.toHexString(Byte.toUnsignedInt(b)));
            sb.append("-");
        }
        return sb.toString();
    }
    
    public static String asHex(final String sep, final byte... data) {
        final StringBuilder sb = new StringBuilder();
        final int adjLen = data.length - 1;
        if (adjLen > 0) {
            for (int i = 0; i < adjLen; ++i) {
                final String hex = Integer.toHexString(Byte.toUnsignedInt(data[i]));
                if (hex.length() < 2) {
                    sb.append("0");
                }
                sb.append(hex);
                sb.append(sep);
            }
        }
        final String hex2 = Integer.toHexString(Byte.toUnsignedInt(data[adjLen]));
        if (hex2.length() < 2) {
            sb.append("0");
        }
        sb.append(hex2);
        return sb.toString();
    }
    
    public static byte[] parseMacAddress(final String hexString) {
        final ByteArrayOutputStream out = new ByteArrayOutputStream(6);
        final String[] split;
        final String[] parts = split = hexString.split(":");
        for (final String s : split) {
            final int n = Integer.parseInt(s, 16);
            out.write(n);
        }
        return out.toByteArray();
    }
    
    public static String asRubyBinaryLiteral(final byte[] data) {
        final StringBuilder sb = new StringBuilder();
        final String hex1 = asHex("ZZZ", data);
        sb.append("\\\\x");
        sb.append(hex1.replaceAll("ZZZ", "\\\\\\\\\\\\x"));
        return sb.toString();
    }
    
    public static String readResource(final String path) throws IOException {
        final InputStream in = Utils.class.getResourceAsStream(path);
        final Scanner sc = new Scanner(in);
        sc.useDelimiter("\\Z");
        final String query = sc.next();
        sc.close();
        return query;
    }
    
    public static boolean isNil(final String s) {
        final boolean b = s == null || s.isEmpty();
        return b;
    }
}
