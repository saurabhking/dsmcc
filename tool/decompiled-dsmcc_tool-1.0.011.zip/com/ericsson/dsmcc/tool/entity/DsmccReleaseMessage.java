package com.ericsson.dsmcc.tool.entity;

import java.nio.*;
import java.util.*;
import java.io.*;
import com.ericsson.dsmcc.tool.*;

public class DsmccReleaseMessage
{
    private byte protocolDescriminator;
    private byte dsmccType;
    private byte[] messageId;
    private byte[] transactionid;
    private byte headerReserved;
    private byte adaptationLength;
    private int adaptationLengthAsInt;
    private byte[] messageLength;
    private int messageLengthAsInt;
    private byte[] stbAddr;
    private byte[] sessionNumber;
    private byte[] messageReserved;
    private byte[] uudataLength;
    private int uudataLengthAsInt;
    private byte[] privateDataLength;
    private int privateDataLengthAsInt;
    private byte[] privateData;
    
    public byte getProtocolDescriminator() {
        return this.protocolDescriminator;
    }
    
    public void setProtocolDescriminator(final byte protocolDescriminator) {
        this.protocolDescriminator = protocolDescriminator;
    }
    
    public byte getDsmccType() {
        return this.dsmccType;
    }
    
    public void setDsmccType(final byte dsmccType) {
        this.dsmccType = dsmccType;
    }
    
    public byte[] getMessageId() {
        return this.messageId;
    }
    
    public void setMessageId(final byte... messageId) {
        this.messageId = messageId;
    }
    
    public byte[] getTransactionid() {
        return this.transactionid;
    }
    
    public void setTransactionid(final byte... transactionid) {
        this.transactionid = transactionid;
    }
    
    public byte getHeaderReserved() {
        return this.headerReserved;
    }
    
    public void setHeaderReserved(final byte headerReserved) {
        this.headerReserved = headerReserved;
    }
    
    public byte getAdaptationLength() {
        return this.adaptationLength;
    }
    
    public void setAdaptationLength(final byte adaptationLength) {
        this.adaptationLength = adaptationLength;
        this.adaptationLengthAsInt = Byte.toUnsignedInt(adaptationLength);
    }
    
    public byte[] getMessageLength() {
        return this.messageLength;
    }
    
    public void setMessageLength(final byte... messageLength) {
        this.messageLength = messageLength;
        this.messageLengthAsInt = ByteBuffer.wrap(messageLength).getShort();
    }
    
    public byte[] getStbAddr() {
        return this.stbAddr;
    }
    
    public void setStbAddr(final byte... stbAddr) {
        this.stbAddr = stbAddr;
    }
    
    public byte[] getSessionNumber() {
        return this.sessionNumber;
    }
    
    public void setSessionNumber(final byte... sessionNumber) {
        this.sessionNumber = sessionNumber;
    }
    
    public byte[] getMessageReserved() {
        return this.messageReserved;
    }
    
    public void setMessageReserved(final byte... messageReserved) {
        this.messageReserved = messageReserved;
    }
    
    public byte[] getUudataLength() {
        return this.uudataLength;
    }
    
    public void setUudataLength(final byte... uudataLength) {
        this.uudataLength = uudataLength;
        this.uudataLengthAsInt = ByteBuffer.wrap(uudataLength).getShort();
    }
    
    public byte[] getPrivateDataLength() {
        return this.privateDataLength;
    }
    
    public void setPrivateDataLength(final byte... privateDataLength) {
        this.privateDataLength = privateDataLength;
        this.privateDataLengthAsInt = ByteBuffer.wrap(privateDataLength).getShort();
    }
    
    public byte[] getPrivateData() {
        return this.privateData;
    }
    
    public void setPrivateData(final byte... privateData) {
        this.privateData = privateData;
    }
    
    public int getAdaptationLengthAsInt() {
        return this.adaptationLengthAsInt;
    }
    
    public int getMessageLengthAsInt() {
        return this.messageLengthAsInt;
    }
    
    public int getUudataLengthAsInt() {
        return this.uudataLengthAsInt;
    }
    
    public int getPrivateDataLengthAsInt() {
        return this.privateDataLengthAsInt;
    }
    
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("DsmccReleaseMessage [protocolDescriminator=").append(this.protocolDescriminator).append(", dsmccType=").append(this.dsmccType).append(", messageId=").append(Arrays.toString(this.messageId)).append(", transactionid=").append(Arrays.toString(this.transactionid)).append(", headerReserved=").append(this.headerReserved).append(", adaptationLength=").append(this.adaptationLength).append(", adaptationLengthAsInt=").append(this.adaptationLengthAsInt).append(", messageLength=").append(Arrays.toString(this.messageLength)).append(", messageLengthAsInt=").append(this.messageLengthAsInt).append(", stbAddr=").append(Arrays.toString(this.stbAddr)).append(", sessionNumber=").append(Arrays.toString(this.sessionNumber)).append(", messageReserved=").append(Arrays.toString(this.messageReserved)).append(", uudataLength=").append(Arrays.toString(this.uudataLength)).append(", uudataLengthAsInt=").append(this.uudataLengthAsInt).append(", privateDataLength=").append(Arrays.toString(this.privateDataLength)).append(", privateDataLengthAsInt=").append(this.privateDataLengthAsInt).append(", privateData=").append(Arrays.toString(this.privateData)).append("]");
        return builder.toString();
    }
    
    public byte[] toBytes() throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(this.protocolDescriminator);
        out.write(this.dsmccType);
        out.write(this.messageId);
        out.write(this.transactionid);
        out.write(this.headerReserved);
        out.write(this.adaptationLength);
        out.write(this.messageLength);
        out.write(this.stbAddr);
        out.write(this.sessionNumber);
        out.write(this.messageReserved);
        out.write(this.uudataLength);
        out.write(this.privateDataLength);
        out.write(this.privateData);
        return out.toByteArray();
    }
    
    public String pretty() throws Exception {
        final StringBuilder sb = new StringBuilder();
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(this.protocolDescriminator);
        out.write(this.dsmccType);
        out.write(this.messageId);
        out.write(this.transactionid);
        out.write(this.headerReserved);
        out.write(this.adaptationLength);
        out.write(this.messageLength);
        sb.append("\n\nHEADER: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.stbAddr);
        out.write(this.sessionNumber);
        sb.append("\nSESSION: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.messageReserved);
        sb.append("\nRESERVED: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.uudataLength);
        out.write(this.privateDataLength);
        out.write(this.privateData);
        sb.append("\nUSERDATA: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        return sb.toString();
    }
}
