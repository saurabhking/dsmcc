package com.ericsson.dsmcc.tool.entity;

import java.nio.*;
import java.io.*;
import com.ericsson.dsmcc.tool.*;
import java.util.*;

public class DsmccSetupMessage
{
    private byte protocolDescriminator;
    private byte dsmccType;
    private byte[] messageId;
    private byte[] transactionid;
    private byte headerReserved;
    private byte adaptationLength;
    private int adaptationLengthAsInt;
    private byte[] messageLength;
    private int messageLengthAsInt;
    private byte[] stbAddr;
    private byte[] sessionNumber;
    private byte[] messageReserved;
    private byte clientNsapAfi;
    private byte[] clientPadding1;
    private byte[] clientId;
    private byte[] clientPadding2;
    private byte serverNsapAfi;
    private byte[] serverPadding1;
    private byte[] serverIp;
    private byte[] serverPadding2;
    private byte[] uudataLength;
    private int uudataLengthAsInt;
    private byte[] privateDataLength;
    private int privateDataLengthAsInt;
    private byte protocolId;
    private byte version;
    private byte descriptorCount;
    private int descriptorCountAsInt;
    private byte nodeGroupIdTag;
    private byte nodeGroupIdLength;
    private int nodeGroupIdLengthAsInt;
    private byte[] nodeGroupIdData;
    private byte appReqDataTag;
    private byte appReqDataLength;
    private int appReqDataLengthAsInt;
    private byte[] appReqData;
    private byte assetIdTag;
    private byte assetIdLength;
    private int assetIdLengthAsInt;
    private byte[] assetIdData;
    
    public byte getProtocolDescriminator() {
        return this.protocolDescriminator;
    }
    
    public void setProtocolDescriminator(final byte protocolDescrim) {
        this.protocolDescriminator = protocolDescrim;
    }
    
    public byte getDsmccType() {
        return this.dsmccType;
    }
    
    public void setDsmccType(final byte dsmccType) {
        this.dsmccType = dsmccType;
    }
    
    public byte[] getMessageId() {
        return this.messageId;
    }
    
    public void setMessageId(final byte... messageId) {
        this.messageId = messageId;
    }
    
    public byte[] getTransactionid() {
        return this.transactionid;
    }
    
    public void setTransactionid(final byte... transactionid) {
        this.transactionid = transactionid;
    }
    
    public byte getHeaderReserved() {
        return this.headerReserved;
    }
    
    public void setHeaderReserved(final byte reserved) {
        this.headerReserved = reserved;
    }
    
    public byte getAdaptationLength() {
        return this.adaptationLength;
    }
    
    public void setAdaptationLength(final byte adaptationLength) {
        this.adaptationLength = adaptationLength;
        this.adaptationLengthAsInt = Byte.toUnsignedInt(adaptationLength);
    }
    
    public byte[] getMessageLength() {
        return this.messageLength;
    }
    
    public void setMessageLength(final byte... messageLength) {
        this.messageLength = messageLength;
        this.messageLengthAsInt = ByteBuffer.wrap(messageLength).getShort();
    }
    
    public byte[] getStbAddr() {
        return this.stbAddr;
    }
    
    public void setStbAddr(final byte... stbAddr) {
        this.stbAddr = stbAddr;
    }
    
    public byte[] getSessionNumber() {
        return this.sessionNumber;
    }
    
    public void setSessionNumber(final byte... sessionNumber) {
        this.sessionNumber = sessionNumber;
    }
    
    public byte[] getMessageReserved() {
        return this.messageReserved;
    }
    
    public void setMessageReserved(final byte... reason) {
        this.messageReserved = reason;
    }
    
    public byte[] getUudataLength() {
        return this.uudataLength;
    }
    
    public void setUudataLength(final byte... uudataLength) {
        this.uudataLength = uudataLength;
        this.uudataLengthAsInt = ByteBuffer.wrap(uudataLength).getShort();
    }
    
    public byte[] getPrivateDataLength() {
        return this.privateDataLength;
    }
    
    public void setPrivateDataLength(final byte... privateDataLength) {
        this.privateDataLength = privateDataLength;
        this.privateDataLengthAsInt = ByteBuffer.wrap(privateDataLength).getShort();
    }
    
    public byte getProtocolId() {
        return this.protocolId;
    }
    
    public void setProtocolId(final byte protocolId) {
        this.protocolId = protocolId;
    }
    
    public byte getVersion() {
        return this.version;
    }
    
    public void setVersion(final byte version) {
        this.version = version;
    }
    
    public byte getDescriptorCount() {
        return this.descriptorCount;
    }
    
    public void setDescriptorCount(final byte descriptorCount) {
        this.descriptorCount = descriptorCount;
        this.descriptorCountAsInt = Byte.toUnsignedInt(descriptorCount);
    }
    
    public byte getNodeGroupIdTag() {
        return this.nodeGroupIdTag;
    }
    
    public void setNodeGroupIdTag(final byte nodeGroupIdTag) {
        this.nodeGroupIdTag = nodeGroupIdTag;
    }
    
    public byte getNodeGroupIdLength() {
        return this.nodeGroupIdLength;
    }
    
    public void setNodeGroupIdLength(final byte nodeGroupIdLength) {
        this.nodeGroupIdLength = nodeGroupIdLength;
        this.nodeGroupIdLengthAsInt = Byte.toUnsignedInt(nodeGroupIdLength);
    }
    
    public byte[] getNodeGroupIdData() {
        return this.nodeGroupIdData;
    }
    
    public void setNodeGroupIdData(final byte... nodeGroupIdData) {
        this.nodeGroupIdData = nodeGroupIdData;
    }
    
    public byte getAppReqDataTag() {
        return this.appReqDataTag;
    }
    
    public void setAppReqDataTag(final byte appReqDataTag) {
        this.appReqDataTag = appReqDataTag;
    }
    
    public byte getAppReqDataLength() {
        return this.appReqDataLength;
    }
    
    public void setAppReqDataLength(final byte appReqDataLength) {
        this.appReqDataLength = appReqDataLength;
        this.appReqDataLengthAsInt = Byte.toUnsignedInt(appReqDataLength);
    }
    
    public byte getAssetIdTag() {
        return this.assetIdTag;
    }
    
    public void setAssetIdTag(final byte assetIdTag) {
        this.assetIdTag = assetIdTag;
    }
    
    public byte getAssetIdLength() {
        return this.assetIdLength;
    }
    
    public void setAssetIdLength(final byte assetIdLength) {
        this.assetIdLength = assetIdLength;
        this.assetIdLengthAsInt = Byte.toUnsignedInt(assetIdLength);
    }
    
    public byte[] getAssetIdData() {
        return this.assetIdData;
    }
    
    public void setAssetIdData(final byte... assetIdData) {
        this.assetIdData = assetIdData;
    }
    
    public byte[] getAppReqData() {
        return this.appReqData;
    }
    
    public void setAppReqData(final byte[] appReqData) {
        this.appReqData = appReqData;
    }
    
    public byte getClientNsapAfi() {
        return this.clientNsapAfi;
    }
    
    public void setClientNsapAfi(final byte client_nsap_afi) {
        this.clientNsapAfi = client_nsap_afi;
    }
    
    public byte[] getClientPadding1() {
        return this.clientPadding1;
    }
    
    public void setClientPadding1(final byte[] client_padding1) {
        this.clientPadding1 = client_padding1;
    }
    
    public byte[] getClientId() {
        return this.clientId;
    }
    
    public void setClientId(final byte[] client_id) {
        this.clientId = client_id;
    }
    
    public byte[] getClientPadding2() {
        return this.clientPadding2;
    }
    
    public void setClientPadding2(final byte[] client_padding2) {
        this.clientPadding2 = client_padding2;
    }
    
    public byte getServerNsapAfi() {
        return this.serverNsapAfi;
    }
    
    public void setServerNsapAfi(final byte server_nsap_afi) {
        this.serverNsapAfi = server_nsap_afi;
    }
    
    public byte[] getServerPadding1() {
        return this.serverPadding1;
    }
    
    public void setServerPadding1(final byte[] server_padding1) {
        this.serverPadding1 = server_padding1;
    }
    
    public byte[] getServerIp() {
        return this.serverIp;
    }
    
    public void setServerIp(final byte[] server_id) {
        this.serverIp = server_id;
    }
    
    public byte[] getServerPadding2() {
        return this.serverPadding2;
    }
    
    public void setServerPadding2(final byte[] server_padding2) {
        this.serverPadding2 = server_padding2;
    }
    
    public int getAdaptationLengthAsInt() {
        return this.adaptationLengthAsInt;
    }
    
    public int getMessageLengthAsInt() {
        return this.messageLengthAsInt;
    }
    
    public int getUudataLengthAsInt() {
        return this.uudataLengthAsInt;
    }
    
    public int getPrivateDataLengthAsInt() {
        return this.privateDataLengthAsInt;
    }
    
    public int getNodeGroupIdLengthAsInt() {
        return this.nodeGroupIdLengthAsInt;
    }
    
    public int getAppReqDataLengthAsInt() {
        return this.appReqDataLengthAsInt;
    }
    
    public int getAssetIdLengthAsInt() {
        return this.assetIdLengthAsInt;
    }
    
    public int getDescriptorCountAsInt() {
        return this.descriptorCountAsInt;
    }
    
    public byte[] toBytes() throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(this.protocolDescriminator);
        out.write(this.dsmccType);
        out.write(this.messageId);
        out.write(this.transactionid);
        out.write(this.headerReserved);
        out.write(this.adaptationLength);
        out.write(this.messageLength);
        out.write(this.stbAddr);
        out.write(this.sessionNumber);
        out.write(this.messageReserved);
        out.write(this.clientNsapAfi);
        out.write(this.clientPadding1);
        out.write(this.clientId);
        out.write(this.clientPadding2);
        out.write(this.serverNsapAfi);
        out.write(this.serverPadding1);
        out.write(this.serverIp);
        out.write(this.serverPadding2);
        out.write(this.uudataLength);
        out.write(this.privateDataLength);
        out.write(this.protocolId);
        out.write(this.version);
        out.write(this.descriptorCount);
        out.write(this.nodeGroupIdTag);
        out.write(this.nodeGroupIdLength);
        out.write(this.nodeGroupIdData);
        out.write(this.appReqDataTag);
        out.write(this.appReqDataLength);
        out.write(this.appReqData);
        return out.toByteArray();
    }
    
    public String pretty() throws Exception {
        final StringBuilder sb = new StringBuilder();
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(this.protocolDescriminator);
        out.write(this.dsmccType);
        out.write(this.messageId);
        out.write(this.transactionid);
        out.write(this.headerReserved);
        out.write(this.adaptationLength);
        out.write(this.messageLength);
        sb.append("\n\nHEADER: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.stbAddr);
        out.write(this.sessionNumber);
        sb.append("\nSESSION: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.messageReserved);
        sb.append("\nRESERVED: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.clientNsapAfi);
        out.write(this.clientPadding1);
        out.write(this.clientId);
        out.write(this.clientPadding2);
        sb.append("\nCLIENT-NSAP: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.serverNsapAfi);
        out.write(this.serverPadding1);
        out.write(this.serverIp);
        out.write(this.serverPadding2);
        sb.append("\nSERVER-NSAP: \n\t").append(Utils.asHex("-", out.toByteArray()));
        out.reset();
        out.write(this.uudataLength);
        out.write(this.privateDataLength);
        out.write(this.protocolId);
        out.write(this.version);
        out.write(this.descriptorCount);
        out.write(this.nodeGroupIdTag);
        out.write(this.nodeGroupIdLength);
        out.write(this.nodeGroupIdData);
        out.write(this.appReqDataTag);
        out.write(this.appReqDataLength);
        out.write(this.appReqData);
        sb.append("\nUSERDATA: \n\t").append(Utils.asHex("-", out.toByteArray()));
        sb.append("\n\tAPP-REQUEST-DATA:\n\t\t").append(new String(this.appReqData));
        out.reset();
        return sb.toString();
    }
    
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("DsmccSetupMessage [protocolDescriminator=").append(this.protocolDescriminator).append(", dsmccType=").append(this.dsmccType).append(", messageId=").append(Arrays.toString(this.messageId)).append(", transactionid=").append(Arrays.toString(this.transactionid)).append(", headerReserved=").append(this.headerReserved).append(", adaptationLength=").append(this.adaptationLength).append(", messageLength=").append(Arrays.toString(this.messageLength)).append(", stbAddr=").append(Arrays.toString(this.stbAddr)).append(", sessionNumber=").append(Arrays.toString(this.sessionNumber)).append(", messageReserved=").append(Arrays.toString(this.messageReserved)).append(", clientNsapAfi=").append(this.clientNsapAfi).append(", clientPadding1=").append(Arrays.toString(this.clientPadding1)).append(", clientId=").append(Arrays.toString(this.clientId)).append(", clientPadding2=").append(Arrays.toString(this.clientPadding2)).append(", serverNsapAfi=").append(this.serverNsapAfi).append(", serverPadding1=").append(Arrays.toString(this.serverPadding1)).append(", serverIp=").append(Arrays.toString(this.serverIp)).append(", serverPadding2=").append(Arrays.toString(this.serverPadding2)).append(", uudataLength=").append(Arrays.toString(this.uudataLength)).append(", privateDataLength=").append(Arrays.toString(this.privateDataLength)).append(", protocolId=").append(this.protocolId).append(", version=").append(this.version).append(", descriptorCount=").append(this.descriptorCount).append(", nodeGroupIdTag=").append(this.nodeGroupIdTag).append(", nodeGroupIdLength=").append(this.nodeGroupIdLength).append(", nodeGroupIdData=").append(Arrays.toString(this.nodeGroupIdData)).append(", appReqDataTag=").append(this.appReqDataTag).append(", appReqDataLength=").append(this.appReqDataLength).append(", appReqData=").append(Arrays.toString(this.appReqData)).append(", assetIdTag=").append(this.assetIdTag).append(", assetIdLength=").append(this.assetIdLength).append(", assetIdData=").append(Arrays.toString(this.assetIdData)).append("]");
        return builder.toString();
    }
}
