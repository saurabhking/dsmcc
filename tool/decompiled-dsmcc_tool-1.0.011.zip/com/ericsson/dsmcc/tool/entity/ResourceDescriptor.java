package com.ericsson.dsmcc.tool.entity;

public class ResourceDescriptor
{
    private byte tag;
    private byte length;
    private int lengthAsInt;
    private byte[] data;
    
    public byte getTag() {
        return this.tag;
    }
    
    public void setTag(final byte tag) {
        this.tag = tag;
    }
    
    public byte getLength() {
        return this.length;
    }
    
    public void setLength(final byte length) {
        this.length = length;
        this.lengthAsInt = Byte.toUnsignedInt(length);
    }
    
    public int getLengthAsInt() {
        return this.lengthAsInt;
    }
    
    public byte[] getData() {
        return this.data;
    }
    
    public void setData(final byte[] data) {
        this.data = data;
    }
}
