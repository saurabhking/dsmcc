package com.ericsson.dsmcc.tool.entity;

public class DsmccSpec
{
    public static final byte PROTO_DESCRIM = 17;
    public static final byte NSAP_AFI = 45;
    public static final short MESSAGE_RESERVED = 0;
    public static final byte HEADER_RESERVED = -1;
    
    public enum ResourceTag
    {
        NodeGroup((byte)2), 
        AppReqData((byte)5), 
        last((byte)3);
        
        private byte id;
        
        private ResourceTag(final byte n) {
            this.id = n;
        }
        
        public byte code() {
            return this.id;
        }
    }
    
    public enum MessageID
    {
        ClientSetupRequest((short)16400), 
        ClientSessionRelRequest((short)16416), 
        Dummy((short)1234);
        
        private short id;
        
        private MessageID(final short n) {
            this.id = n;
        }
        
        public short code() {
            return this.id;
        }
    }
}
