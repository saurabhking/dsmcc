package com.ericsson.dsmcc.tool;

import java.nio.*;
import com.ericsson.dsmcc.tool.entity.*;

public class ReleaseBuilder
{
    private String stbAddr;
    private int sessionNumber;
    private int transactionId;
    private byte[] stbAddrAsBytes;
    
    public ReleaseBuilder(final String stbAddr, final int sessionNumber) {
        this.transactionId = -940572630;
        this.stbAddr = stbAddr;
        this.sessionNumber = sessionNumber;
    }
    
    public DsmccReleaseMessage build() throws Exception {
        final DsmccReleaseMessage dsm = new DsmccReleaseMessage();
        this.stbAddrAsBytes = Utils.parseMacAddress(this.stbAddr);
        int msgLen = 12;
        dsm.setStbAddr(this.stbAddrAsBytes);
        dsm.setSessionNumber(ByteBuffer.allocate(4).putInt(this.sessionNumber).array());
        dsm.setMessageReserved(ByteBuffer.allocate(2).putShort((short)0).array());
        int privDataLength = 0;
        privDataLength += 4;
        dsm.setPrivateData(1, 0, 0, 0);
        dsm.setUudataLength(ByteBuffer.allocate(2).putShort((short)0).array());
        dsm.setPrivateDataLength(ByteBuffer.allocate(2).putShort((short)privDataLength).array());
        msgLen += privDataLength + 4;
        dsm.setProtocolDescriminator((byte)17);
        dsm.setDsmccType((byte)2);
        dsm.setMessageId(ByteBuffer.allocate(2).putShort(DsmccSpec.MessageID.ClientSessionRelRequest.code()).array());
        dsm.setTransactionid(ByteBuffer.allocate(4).putInt(this.transactionId).array());
        dsm.setHeaderReserved((byte)(-1));
        dsm.setAdaptationLength((byte)0);
        dsm.setMessageLength(ByteBuffer.allocate(2).putShort((short)msgLen).array());
        return dsm;
    }
}
